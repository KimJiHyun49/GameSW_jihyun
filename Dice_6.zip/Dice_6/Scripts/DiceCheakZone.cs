using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiceCheakZone : MonoBehaviour
{
	Vector3 diceVelocity1;
	Vector3 diceVelocity2;
	public static int diceNumber1, diceNumber2;
	
	void FixedUpdate()
	{
		diceVelocity1 = RollingDice1.diceVelocity;
		diceVelocity2 = RollingDice2.diceVelocity;
	}

	void OnTriggerStay(Collider col)
	{
		if (diceVelocity1.x == 0f && diceVelocity1.y == 0f && diceVelocity1.z == 0f)
		{
			switch (col.gameObject.name)
			{
				case "side1":
					diceNumber1 = 6;
					break;
				case "side2":
					diceNumber1 = 5;
					break;
				case "side3":
					diceNumber1 = 4;
					break;
				case "side4":
					diceNumber1 = 3;
					break;
				case "side5":
					diceNumber1 = 2;
					break;
				case "side6":
					diceNumber1 = 1;
					break;
			}
		}
		if (diceVelocity2.x == 0f && diceVelocity2.y == 0f && diceVelocity2.z == 0f)
		{
			switch (col.gameObject.name)
			{
				case "side1":
					diceNumber2 = 6;
					break;
				case "side2":
					diceNumber2 = 5;
					break;
				case "side3":
					diceNumber2 = 4;
					break;
				case "side4":
					diceNumber2 = 3;
					break;
				case "side5":
					diceNumber2 = 2;
					break;
				case "side6":
					diceNumber2 = 1;
					break;
			}
		}
		DiceNumber.sum = diceNumber1 + diceNumber2;

	}
}