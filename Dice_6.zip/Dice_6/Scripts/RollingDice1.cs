using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RollingDice1 : MonoBehaviour
{
	static Rigidbody rb;
	public static Vector3 diceVelocity;

	// Use this for initialization
	void Start()
	{
		rb = GetComponent<Rigidbody>();
		int rotx = Random.Range(-60, 60);
		int roty = Random.Range(-60, 60);
		int rotz = Random.Range(-60, 60);
		transform.rotation = Quaternion.Euler(rotx, roty, rotz);
	}

	// Update is called once per frame
	void Update()
	{
			diceVelocity = rb.velocity;

			if (Input.GetKeyDown(KeyCode.Space))
			{
			    DiceCheakZone.diceNumber1 = 0;
			    float dirX = Random.Range(0, 500);
				float dirY = Random.Range(0, 500);
				float dirZ = Random.Range(0, 500);
				transform.position = new Vector3(0, 2, 0);
				rb.AddForce(transform.up * 500);
				rb.AddTorque(dirX, dirY, dirZ);
			}
	}
}