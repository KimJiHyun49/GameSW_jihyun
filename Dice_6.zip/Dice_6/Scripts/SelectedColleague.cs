using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectedColleague : MonoBehaviour
{
    public GameObject[] BasicCharactors;
    public GameObject colleague;
    void Start()
    {
        colleague = Instantiate(BasicCharactors[(int)DataManager.instance.currentColleague]);
        colleague.transform.position = transform.position;
    }
}
