using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DiceNumber : MonoBehaviour
{
	TextMeshProUGUI text;
	public static int sum;

	void Start()
	{
		text = GetComponent<TextMeshProUGUI>();
	}

	void Update()
	{
		text.text = sum.ToString();
	}
}
